from matplotlib import pyplot as plt
from matplotlib.patches import Patch
import matplotlib.colors as mcolors
from generator2 import get_job_id_by_fea


def draw_gantt(chromosomes, AGV_num, TT,PT):
    machine_available = {}
    agv_available = [0] * AGV_num
    agv_position = [0] * AGV_num
    job_position = [0] * len(chromosomes[1])
    job_last_end = {job_id: 0 for job_id in range(len(chromosomes[1]))}
    schedule_result = []
    agv_schedule = []
    job_start_fea = [0 for _ in range(len(PT))]
    job_end_fea = [0 for _ in range(len(PT))]
    end_fea = 0
    start_fea = 0
    for j in range(len(PT)):
        end_fea += len(PT[j])
        job_end_fea[j] = end_fea - 1
    for j in range(len(PT) - 1):
        start_fea += len(PT[j])
        job_start_fea[j + 1] = start_fea
    for idx, (fea_id, op_idx) in enumerate(chromosomes[1]):
        machine_id = chromosomes[2][idx][0]
        agv_id = chromosomes[3][idx]
        op_pt = chromosomes[2][idx][1]
        job_id = get_job_id_by_fea(fea_id, job_end_fea)
        # 计算运输时间
        empty_trans_time = TT[agv_position[agv_id]][job_position[job_id]]
        load_trans_time = TT[job_position[job_id]][machine_id]
        if load_trans_time == 0:
            empty_trans_time = 0
        job_ready_time = job_last_end[job_id]

        # 空载运输开始时间必须在工件准备好之后
        empty_start = max(agv_available[agv_id], job_ready_time - empty_trans_time)
        empty_end = empty_start + empty_trans_time
        load_start = empty_end
        load_end = load_start + load_trans_time

        # 更新AGV状态
        # 更新AGV状态
        if load_trans_time > 0:  # 只有当运输时间大于 0 时才更新 AGV 的位置
            agv_available[agv_id] = load_end
            agv_position[agv_id] = machine_id

        # 加工开始时间
        start_time = max(
            machine_available.get(machine_id, 0),
            load_end
        )
        end_time = start_time + op_pt

        # 更新机器、作业位置和状态
        machine_available[machine_id] = end_time
        job_last_end[job_id] = end_time
        job_position[job_id] = machine_id

        # 保存调度结果
        schedule_result.append((job_id, op_idx, machine_id, start_time, end_time))
        agv_schedule.append({
            'agv_id': agv_id,
            'empty': (empty_start, empty_end),
            'load': (load_start, load_end),
            'job_id': job_id
        })

    # === 绘图部分 === #
    fig, ax = plt.subplots(figsize=(12, 6))
    unique_colors = ['#0984e3', '#00cec9', '#ffeaa7', '#81ecec', '#6c5ce7', '#fd79a8',
         '#74b9ff', '#a29bfe', '#e17055', '#fab1a0', '#55efc4', '#fdcb6e', '#00b894',
         '#6ab04c', '#f7dc6f', '#3498db', '#8e44ad', '#2ecc71',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff',
         '#2980b9', '#c0392b', '#9b59b6', '#e74c3c', '#1abc9c', '#34495e', '#f1c40f', '#7f8c8d',
         '#16a085', '#d35400', '#27ae60', '#f39c12', '#8e44ad', '#c0392b', '#bdc3c7',
         '#7f8c8d', '#1abc9c', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff']
    color_map = {job_id: unique_colors[job_id] for job_id in range(len(chromosomes[1]))}
    # 绘制机器调度条
    for job_id, op_idx, machine_id, start, end in schedule_result:
        ax.barh(machine_id, end - start, left=start,
                height=0.4, color=color_map[job_id], edgecolor='black')

    # AGV调度绘制在机器之后
    machine_max = max(task[2] for task in schedule_result)
    agv_y_offset = machine_max + 1
    for task in agv_schedule:
        agv_y = task['agv_id'] + agv_y_offset

        # 空载运输
        if task['empty'][1] > task['empty'][0]:
            ax.barh(agv_y,
                    task['empty'][1] - task['empty'][0],
                    left=task['empty'][0],
                    height=0.4,
                    color='lightgray',
                    edgecolor='black')
            # 负载运输
        if task['load'][1] > task['load'][0]:
            ax.barh(agv_y,
                    task['load'][1] - task['load'][0],
                    left=task['load'][0],
                    height=0.4,
                    color=color_map[task['job_id']],
                    edgecolor='black')

    # 坐标轴设置
    ax.set_yticks(list(range(machine_max + 1)) + [i + agv_y_offset for i in range(AGV_num)])
    ax.set_yticklabels([f'M{i}' for i in range(machine_max + 1)] + [f'AGV {i}' for i in range(AGV_num)])
    ax.set_title("IPPS-T 综合调度甘特图")
    ax.set_xlabel("时间")
    ax.set_ylabel("资源编号")
    ax.grid(True)

    # 图例
    legend_elements = [
        Patch(facecolor='lightgray', edgecolor='black', label='空载运输'),
        Patch(facecolor='tab:blue', edgecolor='black', label='负载运输（按工件着色）')
    ]
    ax.legend(handles=legend_elements, loc='upper right')

    plt.tight_layout()
    plt.show()