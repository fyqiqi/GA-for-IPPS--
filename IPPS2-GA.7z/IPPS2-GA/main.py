import random
import numpy as np
import argparse
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor, as_completed
from gantt import  draw_gantt
from ipps2dataread import read_fjsp_file
from generator2 import get_travel_time, generate_chromosomes, get_job_id_by_fea
from mutationIPPS2 import mutate_chromosome
import matplotlib

# 设置中文支持
matplotlib.rcParams['font.sans-serif'] = ['Microsoft YaHei']
matplotlib.rcParams['axes.unicode_minus'] = False
def select_parents(solutions, num_pairs, method='roulette'):
    """轮盘赌或锦标赛选择，从 solutions（list of {'chromo','fitness'}）里挑出 num_pairs 对父本。"""
    fitnesses = [sol['fitness'] for sol in solutions]
    # 最小化问题: f 越小，选中概率越大 → 用倒数
    inv = [1.0/(f + 1e-8) for f in fitnesses]
    total = sum(inv)
    probs = [v/total for v in inv]

    pairs = []
    for _ in range(num_pairs):
        if method == 'roulette':
            p1 = random.choices(solutions, weights=probs, k=1)[0]
            p2 = random.choices(solutions, weights=probs, k=1)[0]
        else:  # tournament
            k = 3
            contenders = random.sample(solutions, k)
            p1 = min(contenders, key=lambda x: x['fitness'])
            contenders = random.sample(solutions, k)
            p2 = min(contenders, key=lambda x: x['fitness'])
        pairs.append((p1['chromo'], p2['chromo']))
    return pairs
def generate_offspring_task(sol, parents, AGV_num, TT, M_num, PT,J_num):
    p1 = sol['chromo']
    p2 = np.random.choice(parents)['chromo']
    linkage = build_linkage_model(p1)
    child, _ = gomea_crossover(p1, p2, linkage, AGV_num, TT,M_num,J_num,PT)
    child = enhanced_mutation(child, TT, AGV_num, M_num, PT)
    return child
# 解码染色体计算完工时间
def decode_and_draw_gantt(chromosome, AGV_num, TT,M_num,J_num,PT):
    machine_available = np.zeros(M_num, dtype=int)
    agv_available = np.zeros(AGV_num, dtype=int)
    agv_position = np.zeros(AGV_num, dtype=int)
    job_position = np.zeros(J_num, dtype=int)
    job_last_end = np.zeros(J_num, dtype=int)
    makespan = 0
    job_start_fea = [0 for _ in range(len(PT))]
    job_end_fea = [0 for _ in range(len(PT))]
    end_fea = 0
    start_fea = 0
    for j in range(len(PT)):
        end_fea += len(PT[j])
        job_end_fea[j] = end_fea - 1
    for j in range(len(PT) - 1):
        start_fea += len(PT[j])
        job_start_fea[j + 1] = start_fea
    for idx, (fea_id, op_idx) in enumerate(chromosome[1]):
        machine_id, op_pt = chromosome[2][idx]
        agv_id = chromosome[3][idx]
        job_id = get_job_id_by_fea(fea_id, job_end_fea)
        current_job_pos = job_position[job_id]
        empty_trans = TT[agv_position[agv_id]][current_job_pos]
        load_trans = TT[current_job_pos][machine_id]
        if load_trans == 0:
            empty_trans = 0
        # 计算AGV可用时间和运输时间
        empty_start = max(agv_available[agv_id], job_last_end[job_id] - empty_trans)
        load_end = empty_start + empty_trans + load_trans

        if load_trans > 0:  # 只有当运输时间大于 0 时才更新 AGV 的位置
            agv_available[agv_id] = load_end
            agv_position[agv_id] = machine_id

        # 计算机器开始时间
        start_time = max(machine_available[machine_id-1], load_end)
        end_time = start_time + op_pt

        # 更新状态
        machine_available[machine_id-1] = end_time
        job_last_end[job_id] = end_time
        job_position[job_id] = machine_id
        makespan = max(makespan, end_time)

    return makespan

# 构建链路模型，用于 GOMEA
def build_linkage_model(chromosome):
    length = len(chromosome[0])
    return [[i] for i in range(length)] + [[i, i+1] for i in range(length - 1)]


# GOMEA 交叉
def gomea_crossover(parent1, parent2, linkage_model, AGV_num, TT, M_num, J_num, PT):
    # 先检查染色体是否相同
    if not np.array_equal(parent1[0], parent2[0]):
        return parent1, 1

    for subset in linkage_model:
        trial = [
            parent1[0].copy(),
            [-1] * len(parent1[1]),
            [-1] * len(parent1[2]),
            [-1] * len(parent1[3])
        ]
        op_positions = {op: idx for idx, op in enumerate(parent1[1])}
        for idx in subset:
            op = parent2[1][idx]
            trial[1][idx] = op
            trial[2][idx] = parent2[2][idx]
            trial[3][idx] = parent2[3][idx]
        used_ops = [op for op in trial[1] if op != -1]
        remaining_ops = [op for op in parent1[1] if op not in used_ops]
        empty_positions = [j for j in range(len(trial[1])) if trial[1][j] == -1]
        for pos, op in zip(empty_positions, remaining_ops):
            trial[1][pos] = op
            orig_pos = op_positions[op]
            trial[2][pos] = parent1[2][orig_pos]
            trial[3][pos] = parent1[3][orig_pos]
        # 直接返回第一个生成的子代
        return trial, 0


# 增强变异
def enhanced_mutation(chromosome, TT, AGV_num, M_num, PT):
    return mutate_chromosome(chromosome, TT, AGV_num, M_num, PT)

# 动态种群管理器，包含全局精英与精英派生
class PopulationManager:
    def __init__(self, base_size, AGV_num=None, M_num=None, TT=None, path=None, workers=7,J_num=None,PT=None):
        self.populations = []
        self.base_size = base_size
        self.best_global = None
        self.generation = 0
        self.AGV_num = AGV_num
        self.M_num = M_num
        self.TT = TT
        self.path = path
        self.executor = ProcessPoolExecutor(max_workers=workers)
        self.max_populations = 4  # 限制最大种群数
        self.J_num = J_num
        self.PT = PT
    def evolve(self):
        if self.generation % 10 == 0 and len(self.populations) < self.max_populations:
            # 线性增长：每次加 base_size，而不是乘 2
            new_size = self.base_size
            new_pop = {'size': new_size, 'solutions': [], 'age': 0}
            self.populations.append(new_pop)
            self._evaluate_initial(new_pop)
            # … 注入全局精英 …
            if self.best_global is not None:
                new_pop['solutions'].append({
                    'chromo': [x[:] for x in self.best_global['chromo']],
                    'fitness': self.best_global['fitness']
                })                # 按适应度排序并截断
                new_pop['solutions'] = sorted(new_pop['solutions'], key=lambda x: x['fitness'])[:new_pop['size']]

        # 确保至少有一个种群
        if not self.populations:
            initial = {'size': self.base_size, 'solutions': [], 'age': 0}
            self.populations.append(initial)
            self._evaluate_initial(initial)

        # 对每个子种群进行演化
        for pop in self.populations:
            self._evolve_population(pop)

        # 更新全局最优
        self._update_global_elite()
        # 剪枝，保留包含全局最优的子种群
        self._prune_populations()

        self.generation += 1

    def _evaluate_initial(self, population):
        chromos = [generate_chromosomes(self.path) for _ in range(population['size'])]
        fitnesses = list(self.executor.map(
            decode_and_draw_gantt,
            chromos,
            [self.AGV_num] * population['size'],
            [self.TT] * population['size'],
            [self.M_num] * population['size'],
            [self.J_num] * population['size'],
            [self.PT] * population['size']
        ))
        population['solutions'] = [
            {'chromo': c, 'fitness': f} for c, f in zip(chromos, fitnesses)
        ]
        # 初始时更新全局最优
        self._update_global_elite(population['solutions'])

    def _evolve_population(self, population):
        parents = population['solutions']
        pop_size = population['size']
        # 1. 用选择算子挑出 pop_size//2 对父本
        num_pairs = pop_size // 2
        parent_pairs = select_parents(parents, num_pairs, method='roulette')

        # 2. 并行生成子代
        futures = []
        for p1, p2 in parent_pairs:
            futures.append(
                self.executor.submit(
                    generate_offspring_task,
                    {'chromo': p1, 'fitness': None},  # 为了复用接口，包装成 dict
                    [{'chromo': p2, 'fitness': None}],  # 传入另一个亲本作为“父群”
                    self.AGV_num, self.TT, self.M_num, PT, self.J_num
                )
            )
        # 如果你的 generate_offspring_task 接口直接支持两个 array，也可以直接传 p1,p2

        offspring = [f.result() for f in as_completed(futures)]

        # 3. 评估子代适应度
        fitnesses = list(self.executor.map(
            decode_and_draw_gantt,
            offspring,
            [self.AGV_num] * len(offspring),
            [self.TT] * len(offspring),
            [self.M_num] * len(offspring),
            [self.J_num] * len(offspring),
            [self.PT] * len(offspring)
        ))
        new_sols = [{'chromo': c, 'fitness': f} for c, f in zip(offspring, fitnesses)]

        # 4. 精英保留：保留上一代最优个体
        best_prev = min(parents, key=lambda x: x['fitness'])
        merged = new_sols + [best_prev]

        # 5. 截断到种群规模
        population['solutions'] = sorted(merged, key=lambda x: x['fitness'])[:pop_size]
        # 更新全局最优
        self._update_global_elite(population['solutions'])

    def _update_global_elite(self, candidates=None):
        if not candidates:
            candidates = [
                sol
                for pop in self.populations
                for sol in pop['solutions']
            ]

        if not candidates:
            return

        best_candidate = min(candidates, key=lambda x: x['fitness'])

        if (self.best_global is None or
                best_candidate['fitness'] < self.best_global['fitness']):
            # 仅拷贝必要的数据
            self.best_global = {
                'chromo': [x[:] for x in best_candidate['chromo']],
                'fitness': best_candidate['fitness']
            }

    def _prune_populations(self):
        if not self.populations or self.best_global is None:
            return

        best_fitness = self.best_global['fitness']
        to_remove = []
        for pop in self.populations:
            # 若该子种群含有全局精英，跳过剪枝
            if any(sol['chromo'] == self.best_global['chromo'] for sol in pop['solutions']):
                continue
            avg_fitness = np.mean([sol['fitness'] for sol in pop['solutions']])
            # 仅当平均适应度过差时才删除
            if avg_fitness > best_fitness * 1.2:
                to_remove.append(pop)

        # 保证至少保留一个子种群
        remaining = [pop for pop in self.populations if pop not in to_remove]
        if not remaining and self.populations:
            to_remove = to_remove[:-1]
        for pop in to_remove:
            self.populations.remove(pop)


# 绘制最优解的甘特图

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--path', type=str, default='./ipps2/35x8x3.txt')
    parser.add_argument('--base-size', type=int, default=200)
    parser.add_argument('--generations', type=int, default=10000)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--workers', type=int, default=6)
    args = parser.parse_args()

    np.random.seed(args.seed)
    TT = get_travel_time()
    PT, M_num, Op_num, J_num, AGV_num, arrive_time, due_time, Fea_num, road_fea, constrain = read_fjsp_file(args.path)

    manager = PopulationManager(
        base_size=args.base_size,
        AGV_num=AGV_num,
        M_num=M_num,
        TT=TT,
        path=args.path,
        workers=args.workers,
        J_num=J_num,
        PT=PT
    )

    pbar = tqdm(range(1, args.generations + 1), desc="Generations")
    for iteration in pbar:
        manager.evolve()
        best = manager.best_global
        pbar.set_postfix({'Global Best': best['fitness']})

    # 获取全局最优解并绘制甘特图
    best_solution = manager.best_global['chromo']
    draw_gantt(best_solution, AGV_num, TT,PT)

